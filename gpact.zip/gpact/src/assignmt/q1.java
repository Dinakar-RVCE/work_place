package assignmt;
 import java.util.*;
 class UserMainCode{
	 public static int checksum(long n) {
		 long sum=0;
		 long res=0;
		 while(n>0) {
			 res=n%10;
			 n/=100;
			 sum+=res;
		 }
		 if(sum%2==1) {
			 return 1;
			 
		 }else 
		 {
			 return -1;
			 
		 }
	 }
 }
	 
 

public class q1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc= new Scanner(System.in);
		long n =sc.nextLong();
		System.out.println(UserMainCode.checksum(n));
	}

}
