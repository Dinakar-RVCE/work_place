package day1;
import java.util.Scanner;
public class matrix {
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			Scanner sc = new Scanner(System.in);
			System.out.println("Enter the row size: ");
			int m = sc.nextInt();
			System.out.println("Enter the column size: ");
			int n = sc.nextInt();	
			int UserMatrix[][] = new int[m][n];
			int TransposeMatrix[][] = new int[n][m];
			int counter = 1; int sum = 0; 
			for(int i=0;i<m;i++) {
				for(int j=0;j<n;j++) {
					System.out.println("Enter the element of "+counter+" :");
					UserMatrix[i][j] = sc.nextInt();
					sum +=UserMatrix[i][j];
					counter++;
				}
			}sc.close();
			System.out.println("Matrix entered is");
			for(int i=0;i<m;i++) {
				for(int j=0;j<n;j++) {
					System.out.print(UserMatrix[i][j]+" ");
				}
				System.out.println("");
			}			
			System.out.println("Resulting transpose matrix would be:");
			for (int i = 0; i < m; i++) {
				for (int j = 0; j < n; j++) {
					TransposeMatrix[j][i] = UserMatrix[i][j];
				}
			}
			System.out.println("printing in transpose matrix");
			for(int i=0;i<n;i++) {
				for(int j=0;j<m;j++) {
					System.out.print(TransposeMatrix[i][j]+" ");
				}
				System.out.println("");
			}			
			System.out.println("The sum of the matrix is :"+sum);				
		} 
}
