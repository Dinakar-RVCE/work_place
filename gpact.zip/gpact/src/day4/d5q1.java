package day4;

public class d5q1 {

}
