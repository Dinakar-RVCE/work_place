package day4;

public class mytest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
			X q= new Y();
			q.abc(5);
			
			
	}

}
public class X {
	protected static void abc(int x) {
		System.out.println(x);
	}
}
public class Y extends X{
	
	static void m3(int a)
	{
		System.out.print(a);
	}
}